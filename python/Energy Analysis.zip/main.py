 # -*- coding: utf-8 -*-
# filename: EnergyTset.py
import numpy as np
import pandas as pd
from sklearn.svm import SVR
from sklearn.cross_validation import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import cross_val_predict
from sklearn import preprocessing
from sklearn.metrics import mean_squared_error
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
import matplotlib.pyplot as plt
import pdb
#打开文件

def loadDataSet(fileName):
    #读取数据
    table = pd.read_table (fileName,header = 0,sep=",")
    return table

def FigurePlot():
    ax = plt.subplot(111)
    xmajorLocator = MultipleLocator(24)  # 将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%5.1f')  # 设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.5)  # 将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%1.1f')  # 设置y轴标签文本的格式
    # 设置主刻度标签的位置,标签文本的格式
    ax.xaxis.set_major_locator(xmajorLocator)
    ax.xaxis.set_major_formatter(xmajorFormatter)
    ax.yaxis.set_major_locator(ymajorLocator)
    ax.yaxis.set_major_formatter(ymajorFormatter)

    # 修改次刻度
    xminorLocator = MultipleLocator(6)  # 将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.1)  # 将此y轴次刻度标签设置为0.1的倍数
    # 设置次刻度标签的位置,没有标签文本格式
    ax.xaxis.set_minor_locator(xminorLocator)
    ax.yaxis.set_minor_locator(yminorLocator)

    # 打开网格
    ax.xaxis.grid(True, which='major')  # x坐标轴的网格使用主刻度
    ax.yaxis.grid(True, which='minor')  # y坐标轴的网格使用次刻度
    plt.xlabel('Hour/h')
    plt.ylabel('Energy consumption data/Kwh')

    plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
if __name__=="__main__":
    data=loadDataSet('data\EnergyDataHour.csv')
    plt.plot(data.iloc[650:830])
    plt.show()

    weather = loadDataSet('data\WeatherData.csv')
    print(weather['Date'][:7])
    plt.plot(weather['Date'][:7],weather['Hmax'][:7])
    plt.plot(weather['Date'][:7], weather['Hmin'][:7])
    plt.grid(True)

    df=pd.merge(data, weather, how='inner',left_on='Time',right_on="Date" )
    df=df.drop('Date', axis=1)
    print(df)
    #print(type(df))

    X = df.iloc[:,2:]
    y = df['Value']
    normalized_X=preprocessing.normalize(X)

    #X_train, X_test, y_train, y_test = train_test_split(normalized_X, y,test_size=0.4, random_state=0)
    #model = SVR()
    model = LinearRegression()
    #clf.fit(X_train, y_train)
    #result = clf.predict(X)
    #print(result)
    model.fit(normalized_X,y)
    y_pred=model.predict(normalized_X)

    print(y_pred)
    print(mean_squared_error(y, y_pred))
    #plt.show()
    #print(type(delta))